/** Regression 4 — three lines, 25M = 5M gift + 20M cash; return each line; cash total = 20M, gift total = 5M. */
import { setup } from './_common.mjs'
const h = await setup('reg4-three-lines')
const { one, rows, N, check, snap, steps, capture, salesService, userId, shiftId } = h
const a = h.variant('A 10M', 10_000_000), b = h.variant('B 10M', 10_000_000), c = h.variant('C 5M', 5_000_000)
const g = await h.gift(5_000_000, 7)
const inv = await h.sale([[a, 10_000_000], [b, 10_000_000], [c, 5_000_000]], 20_000_000, g, 5_000_000, 'r4')
snap('before')
const out = []
for (const [v, full] of [[a, false], [b, false], [c, true]]) {
  const item = h.itemOf(inv.id, v)
  const pv = await salesService.returnProvenancePreview({ invoiceId: inv.id, lines: [{ saleItemId: item, qty: 1 }] })
  const r = await capture(() => salesService.createReturn({ invoiceId: inv.id, full, lines: [{ saleItemId: item, qty: 1 }],
    refundMethod: 'CASH', refundAmount: pv.cashRight, userId, shiftId }))
  out.push({ preview: pv, ok: r.ok, error: r.error ?? null, refund: r.value?.refundAmount ?? null, restored: r.value?.creditOpportunity?.restored ?? null })
  check(`return line ${out.length} accepted`, r.ok, r.ok ? { cash: pv.cashRight, gift: pv.giftOpportunity } : r.error)
}
steps.returns = out
const cash = out.reduce((s, x) => s + N(x.refund ?? 0), 0), gift = out.reduce((s, x) => s + N(x.restored ?? 0), 0)
check('Σ cash refunded = 20M (never more)', cash === 20e6, cash)
check('Σ gift restored = 5M', gift === 5e6, gift)
check('per-line split 8M/2M, 8M/2M, 4M/1M', out.map((x) => `${x.preview.cashRight}/${x.preview.giftOpportunity}`).join() === '8000000/2000000,8000000/2000000,4000000/1000000', out.map((x) => [x.preview.cashRight, x.preview.giftOpportunity]))
const live = rows(`SELECT COALESCE(SUM(amount-usedAmount),0) s FROM "StoreCredit" WHERE status IN ('ACTIVE','DRAFT')`)[0].s
check('live gift value ≤ 5M (no double gift)', N(live) <= 5e6, N(live))
const cm = rows(`SELECT COALESCE(SUM(amount),0) s FROM "CashMovement" WHERE type='RETURN_REFUND'`)[0].s
check('CashMovement RETURN_REFUND Σ = 20M', N(cm) === 20e6, N(cm))
snap('after')
h.finish()
