process.argv[2]='04-three-lines'; const c=await import('./scenario-common.mjs');
const gift=await c.db.$transaction(tx=>c.issueStoreCredit(tx,{source:'MANUAL',amount:5000000,multiUse:false,maxUses:1,carryRemainder:false,days:7,userId:c.userId,note:'scenario gift'}));
const a=c.v(10000000),b=c.v(10000000),d=c.v(5000000);
const sale=await c.salesService.create({userId:c.userId,shiftId:c.shiftId,lines:[c.line(a,10000000),c.line(b,10000000),c.line(d,5000000)],payments:[{methodId:c.cash,amount:20000000,destination:'CASH'}],storeCreditCode:gift.code,storeCreditAmount:5000000,storeCreditIdempotencyKey:'s4'});
const items=c.rows('SELECT id FROM "SaleInvoiceItem" WHERE invoiceId=? ORDER BY id',sale.id);
const before=c.snap();
const op=await c.attempt(()=>c.salesService.createReturn({invoiceId:sale.id,lines:items.map(x=>({saleItemId:x.id,qty:1})),full:true,refundMethod:'CASH',refundAmount:20000000,userId:c.userId,shiftId:c.shiftId}));
console.log(JSON.stringify({scenario:'4b-fixed',before,operation:op,after:c.snap(),sourceRefs:['SalesService.createReturn']}))
