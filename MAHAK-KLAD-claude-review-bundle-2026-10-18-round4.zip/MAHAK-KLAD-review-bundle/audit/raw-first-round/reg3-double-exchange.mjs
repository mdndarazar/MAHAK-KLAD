/** Regression 3 — exchange twice: grandchild allocation keeps rootCreditId=1. */
import { setup } from './_common.mjs'
const h = await setup('reg3-double-exchange')
const { one, rows, check, snap, steps, capture, salesService, PW, userId, shiftId, methodId } = h
const vO = h.variant('orig', 15_000_000), vR1 = h.variant('r1', 15_000_000), vR2 = h.variant('r2', 15_000_000)
const g = await h.gift(2_000_000, 7)
const inv = await h.sale([[vO, 15_000_000]], 13_000_000, g, 2_000_000, 'r3')
snap('before')
const exch = (id, from, to) => capture(() => salesService.createExchange({ invoiceId: id, lines: [{ saleItemId: h.itemOf(id, from), qty: 1 }],
  replacements: [{ variantId: to, qty: 1 }], refundMode: 'STORE_CREDIT', methodId, managerPassword: PW, userId, shiftId }))
const e1 = await exch(inv.id, vO, vR1); steps.exchange1 = e1
check('first exchange accepted', e1.ok, e1.ok ? null : e1.error)
const child = one('SELECT id FROM "SaleInvoice" WHERE sourceInvoiceId=?', inv.id)
if (child) {
  const e2 = await exch(child.id, vR1, vR2); steps.exchange2 = e2
  check('second exchange accepted', e2.ok, e2.ok ? null : e2.error)
  const gc = one('SELECT id FROM "SaleInvoice" WHERE sourceInvoiceId=?', child.id)
  check('grandchild exists', !!gc, gc)
  const a = rows('SELECT * FROM "CreditReturnAllocation" WHERE invoiceId=?', child.id)
  check('grandchild allocation rootCreditId=1', a.some((x) => x.rootCreditId === 1), a)
} else {
  steps.exchange2 = { blocked: 'no child' }
  check('second exchange reachable', false, 'blocked by first exchange rejection')
}
snap('after')
h.finish()
