/** Regression 2 — mixed exchange: child with GIFT_CARRY + REAL_CASH_CARRY in ledger. Includes cash-only control. */
import { setup } from './_common.mjs'
const h = await setup('reg2-mixed-exchange')
const { one, rows, N, check, snap, steps, capture, salesService, PW, userId, shiftId, methodId } = h
const vO = h.variant('orig', 15_000_000), vR = h.variant('repl', 15_000_000)
const g = await h.gift(2_000_000, 7)
const inv = await h.sale([[vO, 15_000_000]], 13_000_000, g, 2_000_000, 'r2')
const ctl = await h.sale([[vO, 15_000_000]], 15_000_000)
snap('before')
const exch = (id) => capture(() => salesService.createExchange({ invoiceId: id, lines: [{ saleItemId: h.itemOf(id, vO), qty: 1 }],
  replacements: [{ variantId: vR, qty: 1 }], refundMode: 'STORE_CREDIT', methodId, managerPassword: PW, userId, shiftId }))
const ex = await exch(inv.id)
steps.mixed = ex
check('mixed exchange accepted', ex.ok, ex.ok ? null : ex.error)
const child = one('SELECT id FROM "SaleInvoice" WHERE sourceInvoiceId=?', inv.id)
const pays = child ? rows('SELECT amount, destination, storeCreditId FROM "Payment" WHERE invoiceId=?', child.id) : []
check('child has 2M + 13M EXCHANGE_CREDIT ledger rows', pays.length === 2 && pays.every((p) => p.destination === 'EXCHANGE_CREDIT'), pays)
const c = await exch(ctl.id)
steps.cashOnlyControl = c
const cChild = c.ok ? one('SELECT id FROM "SaleInvoice" WHERE sourceInvoiceId=?', ctl.id) : null
const cPays = cChild ? rows('SELECT amount, destination FROM "Payment" WHERE invoiceId=?', cChild.id) : []
console.log('  control (cash-only, NOT scenario):', c.ok ? 'accepted' : c.error, JSON.stringify(cPays))
snap('after')
h.finish({ cashOnlyControl: { ok: c.ok, childPayments: cPays } })
