# Race candidate artifacts not present in this bundle

The previous Claude message reported these hashes, but the actual files were not attached to this workspace and are not fabricated here:
- Candidate ZIP SHA-256 claim: `cad98a42031c52c3daaff59d5e12316efbb978605b65941f6734b1ea58d1ef0b`
- `changed-files.txt` SHA-256 claim: `be9f627259ce18e06c902836b8a8176d3e83d489240d16b4f8d1ef08853bc883`
- `race-fix.patch` SHA-256 claim: `80a35c29a1bd8608586cd5ffb88a82fe3c781196df63a6d2a9f4cf185e73be8e`
- `tests/audit-fixes/fix-followup-correction-finalclose-race.mjs` and candidate run outputs are also absent.

A reviewer must mark the candidate patch/test as unverified unless the actual files are later supplied. The baseline source and earlier race evidence are included separately.
