# Handoff: latest Claude design proposal (2026-10-18)

## Scope/provenance
This is a faithful summary of the latest proposal pasted into the review conversation, not an implementation or test report. The complete pasted proposal was not provided as a file. The source bundle contains the original project source and prior reports; this note preserves the newest proposal's consequential points and open risks for the next reviewer.

## Latest proposal claimed by Claude
- Extends proportional allocation to cheaper-exchange surplus and carry-forward.
- Uses origin-share/allocation records to preserve the lineage of gift, real-cash, debt and newly received payment across child invoices; gift and real-cash portions are not to be conflated.
- Adds return/transfer allocations and releases so a child return can proportionally split gift and real-cash rights.
- Keeps carried funds in `paidTotal`, while stating carry is not current-shift cash received. The proposal nevertheless suggested changing shared `cashLikeReceivedOf` to include carried cash for refund entitlement.
- Proposes transactional compare-and-swap (CAS) on `financialSeq` for legacy shifts and a custody fence in the transaction; adds `financialRevision` updates/triggers for `CashMovement`, `ReturnCorrection`, and `ReturnCorrectionEffect`.
- No implementation, candidate patch/ZIP, tests, or runtime results were supplied with that proposal.

## Independent source-based concern requiring resolution
In `src/main/services/SalesService.ts`, `cashLikeReceivedOf` is not used only for refund-cap calculation. It also feeds return/overpayment decisions (notably code around the helper's callers near lines 3597 and 3711 in the reviewed baseline), and has other callers. Globally counting carried origin cash in this helper risks treating an internal carry as money actually received on the current invoice/shift and can distort overpay or other decisions.

The design should explicitly separate:
1. **Actual cash-like receipt**: evidenced money received for the invoice/shift; used for cashbox/shift/reporting and overpay calculations.
2. **Refund-eligible cash right**: a lineage-backed cap that may include carried real-cash share; used only for refund entitlement and constrained by prior refunds, prior payouts and child transfers.

The exact source call sites and all consumers must be mapped before recommending any function change. Do not silently change the accounting meaning of `cashLikeReceivedOf`.

## Other unresolved design questions
- Define `CASH_RIGHT` lifecycle and settlement: source, cumulative cap, payment/payout linkage to `SaleReturn` and `CashMovement`, idempotency/retry, corrections/voids, and how duplicate payout is impossible. A `CASH_RIGHT` release row alone does not prove a payout lifecycle.
- Specify atomic fence/write ordering for correction/void versus `finalClose`: first conditional write in each transaction, when expected-cash is calculated, revision snapshot/check, relevant triggers, and prevention of self-invalidation or bypass. `recordCashMovement` must be atomic, not read-shift-then-insert.
- Correct source fact: `withSessionActor` injects `custodyFence` into IPC payload when custody is active; baseline service ignores it. The design must show how the service consumes it inside the transaction.
- Proportional allocation for exchange surplus/carry is a fixed requirement, not an open owner choice. Keep it distinct from any separate debt-first ordering rule for item returns.

## Current verification status
- The existing source evidence and prior reports are included in this handoff ZIP.
- No race-fix candidate artifacts (`race-fix.patch`, candidate ZIP, changed-files list, complete candidate test) are available in this workspace. Do not report the candidate as verified.
- Prior temporary SQLite probes are evidence about baseline behavior only. Probe exit code 0 is not automatically a business PASS; use actual assertions and record raw command/output/exit code.
