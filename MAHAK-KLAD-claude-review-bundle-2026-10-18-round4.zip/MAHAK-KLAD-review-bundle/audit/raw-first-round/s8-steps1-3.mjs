/** Scenario 8 · steps 1-3 — mixed exchange must lock gift share (no double spend).
 * HARNESS_BIGINT=1 node --import ./test/harness/register.mjs tests/scenario8/s8-steps1-3.mjs */
import { setup } from './_common.mjs'
const h = await setup('s8-steps1-3')
const { one, rows, N, check, snap, steps, capture, salesService, SC, db, PW, userId, shiftId, methodId } = h

// ---- fixture: 15M = gift 2M (MANUAL, 7d, single-use) + cash 13M ----
const vOrig = h.variant('original 15M', 15_000_000)
const vRepl = h.variant('replacement 15M', 15_000_000)
const vNew = h.variant('new purchase 2M', 2_000_000)
const g = await h.gift(2_000_000, 7)
const parentInv = await h.sale([[vOrig, 15_000_000]], 13_000_000, g, 2_000_000, 's8-spend')
const p0 = one('SELECT id,status,amount,usedAmount FROM "StoreCredit" WHERE id=?', g.id)
check('fixture: StoreCredit.id=1 amount=2M USED usedAmount=2M',
  p0.id === 1 && N(p0.amount) === 2_000_000 && p0.status === 'USED' && N(p0.usedAmount) === 2_000_000, p0)
check('fixture: parent SaleInvoice.id=1 grand 15M', parentInv.id === 1 && N(parentInv.grandTotal) === 15_000_000,
  { id: parentInv.id, grandTotal: parentInv.grandTotal })
snap('before')

// ---- step 1: createExchange on parent, replacement 15M ----
console.log('\nstep 1 · createExchange')
const ex = await capture(() => salesService.createExchange({
  invoiceId: parentInv.id, lines: [{ saleItemId: h.itemOf(parentInv.id, vOrig), qty: 1 }],
  replacements: [{ variantId: vRepl, qty: 1 }], refundMode: 'STORE_CREDIT', methodId,
  managerPassword: PW, userId, shiftId }))
steps.step1 = ex
check('step1: createExchange succeeded (no blanket rejection)', ex.ok, ex.ok ? null : ex.error)
const child = one('SELECT id, sourceInvoiceId, grandTotal, orderType FROM "SaleInvoice" WHERE sourceInvoiceId=?', parentInv.id)
check('step1: child SaleInvoice.id=2 with sourceInvoiceId=1', child?.id === 2 && child?.sourceInvoiceId === 1, child ?? null)
const childPays = child ? rows('SELECT id, amount, destination, storeCreditId, note FROM "Payment" WHERE invoiceId=?', child.id) : []
check('step1: child payments = 2M GIFT_CARRY + 13M REAL_CASH_CARRY (EXCHANGE_CREDIT)',
  childPays.length === 2 && childPays.every((p) => p.destination === 'EXCHANGE_CREDIT') &&
  childPays.map((p) => N(p.amount)).sort((a, b) => a - b).join() === '2000000,13000000', childPays)
const p1 = one('SELECT status, usedAmount FROM "StoreCredit" WHERE id=1')
check('step1: parent credit stays USED (not ACTIVE)', p1.status === 'USED', p1)
const alloc1 = rows('SELECT * FROM "CreditReturnAllocation"')
check('step1: allocation kind=TRANSFERRED parent=1 root=1 successor=2',
  alloc1.some((a) => a.kind === 'TRANSFERRED' && a.parentCreditId === 1 && a.rootCreditId === 1 && a.successorCreditId === 2), alloc1)
const spendable = rows(`SELECT id, status, amount, usedAmount FROM "StoreCredit" WHERE id<>1 AND status='ACTIVE'`)
check('step1: no deliverable/spendable StoreCredit minted', spendable.length === 0, spendable)
snap('after_step1')

// ---- step 2: try to spend StoreCredit.id=2 (gift carry) ----
console.log('\nstep 2 · spend gift carry')
const c2 = one('SELECT * FROM "StoreCredit" WHERE id=2')
steps.step2 = { storeCredit2Exists: !!c2 }
if (c2) {
  const look = await capture(() => SC.findRedeemable(db, c2.code))
  const buy = await capture(() => h.sale([[vNew, 2_000_000]], 0, c2, 2_000_000, 's8-double'))
  steps.step2.lookup = look; steps.step2.purchase = buy
  check('step2: StoreCredit.id=2 lookup rejected (CREDIT_NOT_REDEEMABLE)', !look.ok, look)
  check('step2: new purchase with StoreCredit.id=2 rejected', !buy.ok, buy)
} else {
  check('step2: GIFT_CARRY instrument under test exists (precondition from step1)', false,
    'StoreCredit.id=2 not created → step 2 could not be exercised; blocked by step 1')
}
// independent safety probe: parent code itself must not be spendable while goods are with customer
const parentSpend = await capture(() => h.sale([[vNew, 2_000_000]], 0, g, 2_000_000, 's8-parent-respend'))
steps.step2.parentRespend = parentSpend
check('step2(probe): parent code StoreCredit.id=1 cannot be re-spent', !parentSpend.ok, parentSpend)
snap('after_step2')

// ---- step 3: full return of child, CASH 13M ----
console.log('\nstep 3 · full return of child')
if (child) {
  const r = await capture(() => salesService.createReturn({ invoiceId: child.id, full: true,
    lines: [{ saleItemId: h.itemOf(child.id, vRepl), qty: 1 }], refundMethod: 'CASH', refundAmount: 13_000_000, userId, shiftId }))
  steps.step3 = r
  check('step3: createReturn on child succeeded', r.ok, r.ok ? null : r.error)
  const sr = one('SELECT id,total,refundAmount,creditRestored FROM "SaleReturn" WHERE invoiceId=?', child.id)
  check('step3: SaleReturn total=15M refund=13M creditRestored=2M',
    sr && N(sr.total) === 15e6 && N(sr.refundAmount) === 13e6 && N(sr.creditRestored) === 2e6, sr)
  const a3 = rows('SELECT kind, amount FROM "CreditReturnAllocation" WHERE returnId=?', sr?.id ?? -1)
  check('step3: allocation ORIGINAL_REVERSED 2M', a3.some((a) => a.kind === 'ORIGINAL_REVERSED' && N(a.amount) === 2e6), a3)
  const p3 = one('SELECT status, usedAmount FROM "StoreCredit" WHERE id=1')
  check('step3: parent credit ACTIVE usedAmount=0', p3.status === 'ACTIVE' && N(p3.usedAmount) === 0, p3)
  const cm = rows(`SELECT type, amount, shiftId FROM "CashMovement" WHERE type='RETURN_REFUND'`)
  check('step3: CashMovement RETURN_REFUND=13M on current shift',
    cm.length === 1 && N(cm[0].amount) === 13e6 && cm[0].shiftId === shiftId, cm)
} else {
  steps.step3 = { blocked: 'no child invoice (step 1 failed)' }
  check('step3: child invoice exists to return', false, 'blocked by step 1')
}
// global invariant: real-money entitlement never > 13M
const cashOut = rows(`SELECT COALESCE(SUM(amount),0) s FROM "CashMovement" WHERE type IN ('RETURN_REFUND','EXCHANGE_REFUND')`)[0].s
const liveCredit = rows(`SELECT COALESCE(SUM(amount-usedAmount),0) s FROM "StoreCredit" WHERE status IN ('ACTIVE','DRAFT') AND voidedAt IS NULL`)[0].s
check('invariant: total cash refunded ≤ 13M', N(cashOut) <= 13e6, N(cashOut))
check('invariant: live gift value ≤ 2M (no double gift)', N(liveCredit) <= 2e6, N(liveCredit))
snap('after')
h.finish()
