# نقطهٔ ادامهٔ طرح نهایی — 2026-10-18

## دستور به کلاد بعدی
فقط پرامپت `CLAUDE-PROMPT-final-design-continuation-fa.txt` را اجرا کن: ادامهٔ طراحی از این نقطه، نه ممیزی مجدد. این فایل handoff و پرامپت هر دو داخل ZIP هستند.

## وضعیت سورس بسته
این ZIP از working tree کامل موجود در زمان بسته‌بندی ساخته شده، نه صرفاً از commit قدیمی. `.git` و dependency/build/cache، دیتابیس محلی و ZIPهای تودرتو داخل آن نیستند. working tree در زمان snapshot حدود 321 entry تغییر/افزودهٔ ثبت‌نشده داشت؛ از این رو محتوای `project/` snapshot سورس حاضر است و لزوماً معادل GitHub HEAD یا نسخهٔ مشتری نیست. `prisma/schema.prisma` فعلی `financialSeq` را ندارد؛ این یک نیاز طراحی/migration آینده است، نه قابلیت موجود. هیچ تستی در این دور اجرا نمی‌شود.

## هدف ثابت پرونده
حل همان مسئلهٔ فروش اعتبار/وجه مختلط، تعویض سالم، برگشت جزئی/کامل فرزند، و استفادهٔ امن از اعتبار. صورت مسئله نباید با رد همگانی، پاک‌کردن سوابق، یا تبدیل هدیه به وجه حذف شود.

## تصمیم‌های قطعی
- تخصیص proportional و rounding تجمعی با integer Rial برای قلم، مازاد B/N و برگشت/انتقال جزئی الزامی است؛ سیاست gift-first/cash-first یا «فقط برگشت کامل/اولین برگشت» جایگزین پذیرفته‌شده نیست.
- B = فرصت هدیهٔ محدود به lineage؛ N = حق وجه واقعی. N به معنای پرداخت انجام‌شده یا cash received امروز نیست.
- event ledger append-only است؛ balance صرفاً projection است؛ retry با همان idempotency key دوباره اثر مالی ایجاد نمی‌کند؛ UNKNOWN حدس زده نمی‌شود.
- اصلاح برگشت شاخه‌دار باید append-only و شاهددار باشد.

## اعداد مرجع مورد توافق
منشأ: 15,980,000 = هدیه 2,000,000 + وجه 13,980,000. تعویض فرزند: 15,000,000.
- سهم carry در فرزند: gift 1,877,346؛ cash 13,122,654.
- مازاد: B 122,654؛ N 857,346 (N هنوز پرداخت واقعی نشده).
- برگشت 6,000,000 از کالای فرزند: سهم خود قلم gift 750,938 + cash 5,249,062؛ سهم متناسب B/N gift 49,062 + cash-right 342,938. جمعاً gift 800,000 و cash 5,592,000 از کل lineage.
- برگشت مکمل 9,000,000: سهم خود قلم gift 1,126,408 + cash 7,873,592؛ سهم B/N gift 73,592 + cash-right 514,408. جمعاً gift 1,200,000 و cash 8,388,000.
- دو برگشت با هم دقیقاً کل 2,000,000 gift + 13,980,000 cash را حفظ می‌کنند.

## دفتر/رویدادهای پذیرفته‌شده
- برای source share: `remaining = initialAmount + Σ(delta)`؛ `ALLOCATE` در initial جذب شده و delta صفر است؛ `CONSUME`/`TRANSFER_OUT` منفی؛ `TRANSFER_IN` و برگشت معتبر مثبت؛ `VOID` دقیقاً معکوس event هدف و دارای `reversesEventId` یکتا.
- `shareId` شناسهٔ branch؛ `rootShareId` بین شاخه‌های یک root مشترک؛ eventهای append-only منبع حقیقت و projection با CAS/version در همان transaction.
- برای local CASH_RIGHT: `open = initial + ΣTRANSFER_IN - ΣTRANSFER_OUT - paid - reserved - converted + recovered`. `paid` پرداخت واقعیِ شاهددار است؛ `recovered` فقط معکوس پرداخت مشخص‌شده؛ transfer والد/فرزند pair و idempotent؛ N را به دریافت نقدی شیفت/overpay تبدیل نکن.

## Guard/custody (طرح، نه قابلیت موجود)
- همهٔ `recordCashMovement`های دارای `shiftId` مشمول guard هستند؛ call-sites شناخته‌شده: `CashMovementService.ts:199`, `CashboxService.ts:938`, `CustodyService.ts:2578/3521`, `SalesService.ts:3867/6941/9625/9651`.
- close legacy: داخل یک transaction روی `Shift(id, closedAt IS NULL, financialSeq=n)` CAS و رزرو n→n+1؛ close-internal `OPENING_FLOAT` از توکن همان tx استفاده می‌کند؛ close نهایی فقط اگر همان sequence و closedAt-null برقرار است شیفت را می‌بندد. هر writer legacy دیگر CAS خودش را می‌گیرد. `financialSeq` در snapshot نیست و migration افزایشی آینده لازم است.
- custody-active از `CustodyState` fence/epoch/revision استفاده می‌کند؛ CashMovementهای اثرگذار باید revision blue را invalidate کنند؛ پس از stale count، recount لازم است.
- `shiftId:null` shift-bound نیست، اما همچنان fence بازه/سامانه لازم دارد.

## بازهای فنی برای تکمیل، نه ممیزی دوباره
در یک مشخصات نهایی باید: قیدهای DB و انتقال اتمیک event/projection، semantic دقیق recovery/VOID، enforce توکن guard برای helper و همهٔ call-sites، retry محدود SQLite busy با همان request key، جریان تحویل B/N و برخورد debt/check/UNKNOWN در سناریوهای توافق‌شده به‌شکل کوتاه و سازگار مشخص شود. این‌ها هنوز implementation/test proof نیستند.
