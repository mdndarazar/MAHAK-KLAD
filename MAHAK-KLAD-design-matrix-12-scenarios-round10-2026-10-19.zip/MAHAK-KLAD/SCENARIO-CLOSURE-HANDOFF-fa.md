# Handoff دور پایانی سناریوها — 2026-10-18

## نقطهٔ ادامه
این بسته برای کلاد جدید است. فقط سناریوهای ۱، ۵، ۷، ۸ از ماتریس هشت‌گانه هنوز به تکمیل/رفع تناقض نیاز دارند؛ موارد قبلاً بسته‌شده را دوباره ممیزی نکن. پرامپت دقیق: `CLAUDE-PROMPT-scenario-closure-round6-fa.txt`.

## وضعیت و منشأ بسته
سورس داخل ZIP snapshot working tree تهیه‌شده در `MAHAK-KLAD-final-design-continuation-2026-10-18.zip` است؛ `.git`، node_modules، build/cache، دیتابیس محلی و ZIPهای تودرتو ندارد. در snapshot قبلی branch arena/8a852de1-mahak-klad روی HEAD `44a86434d9f26dc85b3be68dc48d7b4bcf4b94ea` بود و working tree تغییرات ثبت‌نشده داشت. از آن زمان کد پروژه تغییر نکرده؛ این ZIP برای ادامهٔ طراحی است، نه اثبات کد/نسخهٔ نصب‌شده. هیچ تست یا PASS اجرایی ادعا نشده.

## تصمیم‌ها و قواعد ثابت
- تخصیص proportional و cumulative floor با integer Rial برای کالای برگشتی، مازاد B/N و انتقال به برگشت جزئی الزامی است.
- B: هدیهٔ ریشه‌دار، expiry آن از root می‌آید و از آن دیرتر نیست.
- N: طلب وجه واقعی و بدون انقضا؛ فقط access code آن ممکن است منقضی/باطل شود. حق N با شاهد قابل پرداخت یا reissue است.
- Debt/Cheque pending پول وصول‌شده نیست؛ قبل از وصول نقد صندوق نساز.
- Ledger رویدادی append-only، Payout بر حسب channel، Quarantine برداری، و CAS/leaseهای custody و legacy در جمع‌بندی قبلی پذیرفته شده‌اند؛ این دور آن‌ها را بازنویسی نکن.

## مثال مرجع ثابت
اصل: 15,980,000 = GIFT 2,000,000 + CASH 13,980,000. تعویض: کالای 15,000,000.
- carry فرزند: GIFT 1,877,346 + CASH 13,122,654.
- surplus: B 122,654 + N 857,346.
- partial return 6,000,000: سهم کالا GIFT 750,938 + CASH 5,249,062؛ سهم B/N برابر 49,062 + 342,938؛ aggregate آن برگشت: GIFT 800,000 + CASH 5,592,000.
- مکمل 9,000,000: سهم کالا GIFT 1,126,408 + CASH 7,873,592؛ سهم B/N برابر 73,592 + 514,408؛ aggregate: GIFT 1,200,000 + CASH 8,388,000.
- مجموع: دقیقاً 2M GIFT + 13.98M CASH.

## چهار شکاف سناریویی باقی‌مانده
1. S1/E1/R1 v3 پیش‌تر شامل استفاده از 400K+580K N، تلاش سوم 1 Rial، دو قلم 14M+1M و برگشت آن‌ها بود. پس از proportional، حق نقدی N فقط 857,346 و B=122,654 است؛ سناریو باید بدون بازگرداندن فرض قدیمی N=980K بازنویسی شود.
2. v3 debt-first case: خرید 1.2M (H1 300K + cash 900K), exchange to 1.5M, extra 300K either collected cash or DEBT/CHEQUE_PENDING. گزارش قبلی دربارهٔ برگشت 300K و کاهش بدهی 240K با debt_first تعریف‌شده ناسازگار است و باید اصلاح شود؛ روش pending ممکن است اجازهٔ مالک بخواهد.
3. ONCE 10M with 5M spent; two-stage returns B1=2.5M (delivered, 1M spent) and B2=7.5M DRAFT; v3 owner question about the unspent complement 5M and exact correction behavior still needs disposition.
4. Cheque/destination/day: 700K pending cheque + 300K cash, exchange 800K; manager-account settlement separate from store cash/card; operational-day boundary 05:00/MIDDAY; evidence, responsible role and reconciliation deadline not fully specified.

## مقیاس پیشرفت
آخرین جمع‌بندی کلی حدود 86٪ بود، اما هشت ردیف را نمی‌توان 6 بسته/2 ناقص شمرد بدون حل ناسازگاری‌های 1 و 5. هدف این دور فقط تکمیل این چهار سناریو با اعداد و توالی رویداد است؛ نه re-score کلی و نه اجرای تست.
