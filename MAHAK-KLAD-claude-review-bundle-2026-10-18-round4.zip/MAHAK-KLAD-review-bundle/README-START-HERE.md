# MAHAK-KLAD review bundle (2026-10-18)

## Contents
- `project-original/`: exact Git source tree from commit `6379c5fa14ad430a5862af45f16cb3a14cb7f0cc`, the 1,567-file source baseline. It is not a modified/fixed project.
- `audit/reports/`: prior and latest analysis reports and source hashes.
- `audit/latest-followup-evidence.zip` and `audit/latest-followup-evidence-files/`: latest S5/race/rollover evidence package plus its extracted files for convenient review.
- `audit/raw-first-round/`: earlier raw scenario scripts, JSON snapshots, stdout/stderr and exit files that were available.
- `audit-probe-overlay/tools/audit-probes/`: extra probes/helpers. To run one, copy the overlay into a disposable copy of `project-original`; do not alter this bundle or use a real database.
- `audit/candidate-race/MISSING-ARTIFACTS.md`: candidate race patch, candidate ZIP, changed-files file and new candidate test were not available to this workspace. Hashes alone are not those artifacts.

## Provenance and integrity
The original ZIP hash previously reported was `18ebe06b3145d51787113ae919a8267698859c867d73cbfd22420ba503f73028`. This bundle contains the project Git tree at the reported source commit, not the original ZIP byte-for-byte; archive packaging hashes therefore differ. The reported source hashes for `SalesService.ts`, `ShiftService.ts`, and `CustodyService.ts` match the files in `project-original/`.

No application code was changed to create this bundle. A new reviewer should report-only/test-only unless the user separately authorizes implementation. Do not call the old candidate race fix verified without its actual patch/test files.
