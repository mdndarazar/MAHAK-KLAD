/** Regression 1 — full return of mixed 15M (2M gift + 13M cash): parent ACTIVE, ORIGINAL_REVERSED 2M, 13M cash. */
import { setup } from './_common.mjs'
const h = await setup('reg1-full-mixed-return')
const { one, rows, N, check, snap, steps, capture, salesService, userId, shiftId } = h
const v = h.variant('item 15M', 15_000_000)
const g = await h.gift(2_000_000, 7)
const inv = await h.sale([[v, 15_000_000]], 13_000_000, g, 2_000_000, 'r1')
snap('before')
const r = await capture(() => salesService.createReturn({ invoiceId: inv.id, full: true,
  lines: [{ saleItemId: h.itemOf(inv.id, v), qty: 1 }], refundMethod: 'CASH', refundAmount: 13_000_000, userId, shiftId }))
steps.return = r
check('return accepted', r.ok, r.ok ? null : r.error)
const sr = one('SELECT id,total,refundAmount,creditRestored FROM "SaleReturn" WHERE invoiceId=?', inv.id)
check('SaleReturn total=15M refund=13M creditRestored=2M', sr && N(sr.total) === 15e6 && N(sr.refundAmount) === 13e6 && N(sr.creditRestored) === 2e6, sr)
const a = rows('SELECT kind, amount, parentCreditId, rootCreditId, successorCreditId FROM "CreditReturnAllocation"')
check('allocation ORIGINAL_REVERSED 2M on credit 1', a.length === 1 && a[0].kind === 'ORIGINAL_REVERSED' && N(a[0].amount) === 2e6 && a[0].parentCreditId === 1, a)
const p = one('SELECT status, usedAmount, expiresAt FROM "StoreCredit" WHERE id=1')
check('parent credit ACTIVE, usedAmount=0', p.status === 'ACTIVE' && N(p.usedAmount) === 0, p)
const cm = rows(`SELECT type, amount, shiftId FROM "CashMovement" WHERE type='RETURN_REFUND'`)
check('CashMovement RETURN_REFUND 13M on current shift', cm.length === 1 && N(cm[0].amount) === 13e6 && cm[0].shiftId === shiftId, cm)
const extra = rows(`SELECT id FROM "StoreCredit" WHERE id<>1`)
check('no extra credit minted', extra.length === 0, extra)
snap('after')
h.finish()
