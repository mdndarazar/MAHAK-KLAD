/** Regression 6 — GIFT_CARRY rejected after 8 days (7-day root). Plus root-deadline probe on reversed parent. */
import { setup } from './_common.mjs'
const h = await setup('reg6-expiry')
const { one, rows, check, snap, steps, capture, salesService, SC, db, PW, userId, shiftId, methodId } = h
const vO = h.variant('orig', 15_000_000), vR = h.variant('repl', 15_000_000), vN = h.variant('new', 2_000_000)
const g = await h.gift(2_000_000, 7)
const inv = await h.sale([[vO, 15_000_000]], 13_000_000, g, 2_000_000, 'r6')
const inv2 = await h.sale([[vO, 15_000_000]], 15_000_000)
snap('before')
const ex = await capture(() => salesService.createExchange({ invoiceId: inv.id, lines: [{ saleItemId: h.itemOf(inv.id, vO), qty: 1 }],
  replacements: [{ variantId: vR, qty: 1 }], refundMode: 'STORE_CREDIT', methodId, managerPassword: PW, userId, shiftId }))
steps.exchange = ex
check('mixed exchange (precondition) accepted', ex.ok, ex.ok ? null : ex.error)
const carry = one('SELECT * FROM "StoreCredit" WHERE id<>1 ORDER BY id LIMIT 1')
check('GIFT_CARRY instrument exists to age', !!carry, carry ? carry.id : 'blocked by exchange guard')
// probe (NOT scenario 6): reverse parent fully, then +8d → parent code must be expired
const r = await capture(() => salesService.createReturn({ invoiceId: inv.id, full: true, lines: [{ saleItemId: h.itemOf(inv.id, vO), qty: 1 }],
  refundMethod: 'CASH', refundAmount: 13_000_000, userId, shiftId }))
const p = one('SELECT status, expiresAt FROM "StoreCredit" WHERE id=1')
const day0 = await capture(() => SC.findRedeemable(db, g.code))
h.advanceDays(8)
const day8 = await capture(() => SC.findRedeemable(db, g.code))
const buy8 = await capture(() => h.sale([[vN, 2_000_000]], 0, g, 2_000_000, 'r6-late'))
steps.probe = { return: r.ok ? 'ok' : r.error, parent: p, day0: day0.ok ? 'redeemable' : day0.error, day8: day8.ok ? 'redeemable' : day8.error, buy8: buy8.ok ? 'accepted' : buy8.error }
console.log('  probe (reversed parent, root deadline):', JSON.stringify(steps.probe))
snap('after')
h.finish({ probe: { rootDeadlineKept: r.ok && day0.ok && !day8.ok && !buy8.ok } })
