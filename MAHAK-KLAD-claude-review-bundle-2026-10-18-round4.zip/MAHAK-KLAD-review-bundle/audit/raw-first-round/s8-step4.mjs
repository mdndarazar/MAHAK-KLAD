/** Scenario 8 · step 4 (optional) — partial 1M return from 15M child: gift 133,333 DRAFT + cash 866,667.
 * HARNESS_BIGINT=1 node --import ./test/harness/register.mjs tests/scenario8/s8-step4.mjs */
import { setup } from './_common.mjs'
const h = await setup('s8-step4')
const { one, rows, N, check, snap, steps, capture, salesService, PW, userId, shiftId, methodId } = h
// child of 15M needs to be divisible into a 1M unit: 15 × 1M lines
const vOrig = h.variant('orig 1M unit', 1_000_000), vRepl = h.variant('repl 1M unit', 1_000_000)
const g = await h.gift(2_000_000, 7)
const parent = await h.sale([[vOrig, 1_000_000, 15]], 13_000_000, g, 2_000_000, 's8-4')
snap('before')
const ex = await capture(() => salesService.createExchange({ invoiceId: parent.id,
  lines: [{ saleItemId: h.itemOf(parent.id, vOrig), qty: 15 }], replacements: [{ variantId: vRepl, qty: 15 }],
  refundMode: 'STORE_CREDIT', methodId, managerPassword: PW, userId, shiftId }))
steps.exchange = ex
check('pre: mixed exchange produced 15M child', ex.ok, ex.ok ? null : ex.error)
const child = one('SELECT id FROM "SaleInvoice" WHERE sourceInvoiceId=?', parent.id)
if (child) {
  const pv = await capture(() => salesService.returnProvenancePreview({ invoiceId: child.id, lines: [{ saleItemId: h.itemOf(child.id, vRepl), qty: 1 }] }))
  steps.preview = pv
  const r = await capture(() => salesService.createReturn({ invoiceId: child.id, full: false,
    lines: [{ saleItemId: h.itemOf(child.id, vRepl), qty: 1 }], refundMethod: 'CASH', refundAmount: 866_667, userId, shiftId }))
  steps.return = r
  check('step4: return accepted', r.ok, r.ok ? null : r.error)
  check('step4: cash 866,667 / gift 133,333', r.ok && N(r.value.refundAmount) === 866_667 && N(r.value.creditOpportunity?.restored) === 133_333, r.value ?? null)
} else {
  check('step4: child exists for partial return', false, 'blocked by mixed-exchange guard')
}
snap('after_scenario')

// ---- CONTROL (not scenario 8): same proportions applied directly on the parent ----
console.log('\ncontrol · 1M partial return straight from mixed parent (NOT scenario 8)')
const pv0 = await salesService.returnProvenancePreview({ invoiceId: parent.id, lines: [{ saleItemId: h.itemOf(parent.id, vOrig), qty: 1 }] })
const r0 = await capture(() => salesService.createReturn({ invoiceId: parent.id, full: false,
  lines: [{ saleItemId: h.itemOf(parent.id, vOrig), qty: 1 }], refundMethod: 'CASH', refundAmount: pv0.cashRight, userId, shiftId }))
const br = r0.ok ? one('SELECT id, status, amount FROM "StoreCredit" WHERE id=?', r0.value.creditOpportunity?.pendingDelivery?.[0]?.creditId ?? -1) : null
steps.control = { preview: pv0, return: r0, branch: br }
console.log('  control preview', JSON.stringify(pv0), '\n  control branch', JSON.stringify(br))
snap('after')
h.finish({ control: { cashRight: pv0.cashRight, giftOpportunity: pv0.giftOpportunity, branch: br,
  matchesSpec: pv0.cashRight === 866_667 && pv0.giftOpportunity === 133_333 && br?.status === 'DRAFT' } })
