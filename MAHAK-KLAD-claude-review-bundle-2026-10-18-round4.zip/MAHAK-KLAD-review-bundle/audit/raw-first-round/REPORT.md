# گزارش سناریو ۸ (دوبارخرج) + regression

اجرا روی هارنس واقعی پروژه (`node:sqlite` + سرویس‌های واقعی `SalesService`/`StoreCreditService`)، `HARNESS_BIGINT=1`، Node 22.
**کد محصول تغییر نکرد.** هیچ سناریوی FAIL حذف یا نرم نشد. اسکریپت‌ها فقط در `tests/scenario8/` اضافه شدند.
اجرا: `HARNESS_BIGINT=1 node --import ./test/harness/register.mjs tests/scenario8/<file>.mjs`

## جدول نهایی

| سناریو | exit | PASS/FAIL | توضیح |
|---|---|---|---|
| 1 برگشت کامل مختلط | 0 | PASS | والد ACTIVE، usedAmount=0، ORIGINAL_REVERSED 2M، RETURN_REFUND 13M روی شیفت جاری، اعتبار اضافه ساخته نشد |
| 2 تعویض مختلط | 1 | FAIL | `createExchange` رد کلی شد (SalesService.ts:3551). کنترل تمام‌نقد همان پارامترها پذیرفته شد ⇒ خطا از ورودی آزمون نیست |
| 3 دو بار تعویض | 1 | FAIL | تعویض اول رد شد؛ grandchild قابل رسیدن نیست |
| 4 سه قلم (5M هدیه + 20M وجه) | 0 | PASS | تفکیک 8/2، 8/2، 4/1؛ Σوجه=20M، Σهدیه=5M، بدون دوبارخرج |
| 6 انقضا | 1 | FAIL | GIFT_CARRY وجود ندارد که پیر شود (مسدود به‌دلیل 3551). probe کمکی: موعد ریشه پس از برگشت کامل حفظ شد و در روز ۸ رد شد |
| **8 (مرحله ۱-۳)** | 1 | **FAIL** | مرحله ۱ رد کلی ⇒ child/GIFT_CARRY/TRANSFERRED ساخته نشد؛ مراحل ۲ و ۳ مسدود. ایمنی حفظ شد (والد USED، بازخرج والد رد، Σوجه=0≤13M) ولی «رد کلی تعویض» طبق اصل بنیادی ممنوع است |
| 8 (مرحله ۴) | 1 | FAIL | child وجود ندارد. کنترل جداگانه روی والد (نه سناریو ۸): 133,333 هدیه DRAFT + 866,667 نقد دقیقاً مطابق انتظار |
| race | — | NOT RUN | فایل `round3-no-session-race.mjs` در zip نیست. تحلیل ایستا پایین |

## گزارش ریشه: سناریو ۸ / ۲ / ۳ / ۶

**محل:** `src/main/services/SalesService.ts` سطر 3548 تا 3551 (داخل هستهٔ مشترک برگشت/تعویض):
```ts
if (!opts.applyRefund && await tx.payment.count({
  where: { invoiceId: invoice.id, voidedAt: null, storeCreditId: { not: null } }
}))
  throw new BusinessError('تعویضِ خریدی که با اعتبار پرداخت شده فعلاً به تطبیق منشأ توسط مدیر نیاز دارد؛ ...')
```
مسیر تعویض با `applyRefund=false` وارد می‌شود، پس هر فاکتوری که حتی ۱ ریال اعتبار در پرداختش دارد، بدون استثنا رد می‌شود. این «پاک کردن صورت‌مسئله» است: دوبارخرج را با ممنوع کردن کل تعویض جلوگیری می‌کند.

**شکاف مدل داده:** واژگان سناریو در کد وجود ندارد: `GIFT_CARRY`، `REAL_CASH_CARRY`، `TRANSFERRED`، `CREDIT_NOT_REDEEMABLE` هر کدام ۰ رخداد در `src/`. `CreditReturnAllocation.kind` فقط `ORIGINAL_REVERSED | BRANCH | SUPPLEMENT | EXPIRED` است (`prisma/schema.prisma:2739`). پس حتی با حذف گارد، مرحله ۱ بدون migration نمی‌تواند PASS شود.

**درمان پیشنهادی (اجرا نشد، فقط پیشنهاد):**
1. گارد 3551 را با «انتقال منشأ» جایگزین کنید: در مسیر تعویض همان `planCreditReturn` (که مسیر برگشت از آن استفاده می‌کند و در سناریو ۱ و ۴ درست کار می‌کند) را صدا بزنید و به جای وجه/کد، روی child دو ردیف Payment با `destination=EXCHANGE_CREDIT` بنویسید: سهم هدیه (GIFT_CARRY) و سهم نقد (REAL_CASH_CARRY).
2. migration افزایشی: kind جدید `TRANSFERRED` در `CreditReturnAllocation` با `parentCreditId/rootCreditId` = والد و `successorCreditId` = رکورد قفل‌شده (status جدید مثل `LOCKED`، که `findRedeemable` و `create` آن را با دستهٔ `NOT_REDEEMABLE` رد کنند). والد `USED` بماند و `reverseInvoiceRedemptions` روی والد صدا زده نشود.
3. در `CreditReturnService` (حوالی سطر 144 تا 187) هنگام برگشت child، اگر allocation از نوع `TRANSFERRED` بود، زنجیره را تا `rootCreditId` دنبال کنید: برگشت کامل ⇒ `ORIGINAL_REVERSED` روی ریشه؛ برگشت جزئی ⇒ `BRANCH` DRAFT با `expiresAt` ریشه. سقف وجه = جمع REAL_CASH_CARRY.

## ناسازگاری داخلی در متن سناریو (پرچم، نه تغییر)
- مرحله ۱ می‌گوید «هیچ StoreCredit نساز» ولی همزمان `successorCreditId=2` می‌خواهد و مرحله ۲ «StoreCredit.id=2 (اگر ساخته شده)». فقط وقتی سازگار است که id=2 رکوردی **قفل و غیرقابل‌خرج** باشد. آزمون همین تفسیر را چک می‌کند.
- مرحله ۳ می‌گوید والد ⇒ ACTIVE با ORIGINAL_REVERSED؛ معیار قبولی ۳ می‌گوید «۲M شاخه هدیه DRAFT». این دو خروجی متفاوت‌اند. آزمون نسخهٔ مرحله ۳ (والد ACTIVE) را چک می‌کند؛ مالک باید یکی را تعیین کند.

## race (تحلیل ایستا)
- `SaleReturn.shiftId` داخل تراکنش با `shiftService.currentId(tx, ...)` حل می‌شود (SalesService.ts:3781) و CashMovement روی همان شیفت می‌نشیند (سناریو ۱: shiftId=1 ✓).
- **ولی** وقتی custody فعال است و `custodyFence` ارسال نشده، `shiftForNow`/`currentId` (ShiftService.ts:674-677 و 693-695) وضعیت را با `custodyService.isGoverned()/status()` از **کلاینت سراسری `prisma`** می‌خوانند (CustodyService.ts:1231-1256)، نه `tx`. پس شیفت فعال داخل تراکنش بازسنجی نمی‌شود و بین خواندن و commit پنجرهٔ race هست. فقط مسیر دارای fence (`assertFenceInTx(client, …)`) واقعاً درون‌تراکنشی است.
- درمان: `isGoverned/status` نسخهٔ `client`-پذیر بگیرند و در `shiftForNow(tx)` با `tx` صدا زده شوند، یا fence برای همهٔ نویسنده‌های مالی اجباری شود.

## فایل‌ها
- `scripts/*.mjs`: هر سناریو جدا + `_common.mjs` (کمکی آزمون).
- `runs/<name>.json`: خروجی خام با `db.before` و `db.after` (و snapshot مراحل) شامل تمام جدول‌های غیرخالی.
- `runs/<name>.stdout.txt` / `.stderr.txt` / `.exit.txt`.
- `SHA256SUMS.txt`: هش همهٔ فایل‌ها. `source-sha256.txt`: هش سورس‌های ارجاع‌شده.
